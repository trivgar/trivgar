<?
/****************************************************************************************
 * WebChat config file                                                                  *
 *   This file is edited thru the WebChat Administration, DO NOT EDIT HERE!!            *
 *   If edited here, it may not correctly read when editing thru the admin interface.   *
 ****************************************************************************************/
$dbhost = 'localhost';
$dbuname = 'v026740';
$dbpass = 'w2u2n5sq';
$dbname = 'v026740';
$prefix = 'nuke';
$allowcreate = '0';
$onlyregcancreate = '1';
$msg_refresh = '10000';
$usertime = '180';
$showsmiles = '1';
$smilesdir = 'images/smiley';
$usesounds = '1';
$showsounds = '0';
$soundsdir = 'sounds';
$showusers = '1';
$keeponline = '0';
?>