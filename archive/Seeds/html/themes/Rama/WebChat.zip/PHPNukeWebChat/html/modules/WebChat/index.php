<?php 
/*****************************************************************************************
 *  WebChat - multiple private/open room chat system for PostNuke                        *
 *****************************************************************************************
 *   David "Cyklone" Thompson   david@thompsonville.net                                  *
 *   portions credited to Daniel Toma [dt@dnt.ro] [http://www.webdev.ro]                 *
 *****************************************************************************************
 *  Read CHANGELOG for updates and bug fixes                                             *
 *****************************************************************************************
 * POST-NUKE Content Management System                                                   *
 * Copyright (C) 2001 by the Post-Nuke Development Team.                                 *
 * http://www.postnuke.com/                                                              *
 * --------------------------------------------------------------------------------------*
 * Based on:                                                                             *
 * PHP-NUKE Web Portal System - http://phpnuke.org/                                      *
 * Thatware - http://thatware.org/                                                       *
 *****************************************************************************************/

if (!eregi('modules.php', $PHP_SELF)) 
  die ("You can't access this file directly...");

$ModName = $GLOBALS[name];
if(file_exists("modules/$ModName/language/lang-".$currentlang.".php")) {
	include("modules/$ModName/language/lang-".$currentlang.".php");
}
else {
	include("modules/$ModName/language/lang-english.php");
}


if(!file_exists("modules/$ModName/inc/config.php")) {
  include 'header.php';
  OpenTable();
  include "modules/$ModName/wc_header.php";
  if(is_admin($admin)) 
    echo "<p align=\"left\"><font class=\"pn-normal\"><strong>"._WCNOTINSTALLED."</strong></font></p>";
  else
    echo "<p align=\"left\"><font class=\"pn-normal\"><strong>"._WCADMINNEEDED."</strong></font></p>";
  CloseTable();
  include 'footer.php';
  exit;
}

require "modules/$ModName/inc/config.php";


// some cleaning in users ...
// delete users with timestamp < now - $usertime
$tstamp = time();
$tstamp -= $usertime;
$q = mysql_query("delete from ".$prefix."_chatuser where last < ".$tstamp);
$q = mysql_query("delete from ".$prefix."_chatmessage where last < ".$tstamp);

function disp_index($errmsg) {
  global $bgcolor1, $bgcolor2, $bgcolor3, $sitename, $ModName, $prefix, $admin, $showusers, $currentlang, $user, $allowcreate, $onlyregcancreate;
  OpenTable();
  include "modules/$ModName/wc_header.php";
?>
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0" WIDTH="100%" VALIGN="TOP">
  <TR><TD BGCOLOR="<?=$bgcolor2?>">
  <TABLE BORDER="0" CELLPADDING="4" CELLSPACING="1" WIDTH="100%">
    <TR BGCOLOR="<?=$bgcolor2?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD WIDTH="15%"><FONT CLASS="newstitle"><STRONG><?=_WCROOMNAME?></STRONG></FONT></TD>
      <TD WIDTH="10%"><FONT CLASS="newstitle"><STRONG><?=_WCROOMTYPE?></STRONG></FONT></TD>
      <TD WIDTH="55%"><FONT CLASS="newstitle"><STRONG><?=_WCROOMDESC?></STRONG></FONT></TD>
      <TD WIDTH="10%"><FONT CLASS="newstitle"><STRONG><?=_WCROOMOCCUPANTS?></STRONG></FONT></TD>
    </TR>
<?
  $sql = "select ".$prefix."_chatroom.*, count(".$prefix."_chatuser.rid) as users from ".$prefix."_chatroom left join ".$prefix."_chatuser on ".$prefix."_chatuser.rid = ".$prefix."_chatroom.rid group by ".$prefix."_chatroom.rid order by ".$prefix."_chatroom.typ, ".$prefix."_chatroom.name";
  $q=mysql_query($sql);
  if(mysql_num_rows($q) == 0){
    echo "<TR BGCOLOR=$bgcolor1><TD COLSPAN=\"4\"><FONT CLASS=pn-normal><CENTER>"._WCNOACTIVE."</CENTER></FONT></TD></TR>";
  } else {
    while($row=mysql_fetch_array($q)) {
      echo "<TR BGCOLOR=$bgcolor1><TD><FONT CLASS=pn-normal><a href=\"modules.php?op=modload&name=".$ModName."&file=index&roomid=$row[rid]\">$row[name]</a></TD>";
      if($row[typ] == "P") {
        echo "<TD><FONT CLASS=pn-normal>"._WCPRIVROOM."&nbsp;";
        if($row[pass] != "")
          echo "<img src=\"modules/$ModName/images/pass.gif\" alt=\"Password necesario\"></TD>";
      } else
        echo "<TD><FONT CLASS=pn-normal>"._WCNORMROOM."</TD>";
      echo "<TD><FONT CLASS=pn-normal>$row[descript]</TD>";
      echo "<TD ALIGN=\"CENTER\"><FONT CLASS=pn-normal>$row[users]";
      if($showusers && $row[users] > 0){
        echo "<br><i>";
        $first = true;
        $q2 = mysql_query("select name from ".$prefix."_chatuser where rid = ".$row[rid]);
        while($result2 = mysql_fetch_array($q2)){
          if($first) {
            $first = false;
            echo $result2[name];
          } else
            echo ", ".$result2[name]; 
        }
      }
      echo "</i></TD></TR>";
    }
  }
?>
  </TABLE>
  </TD></TR>
</TABLE>
<?
  if( ($allowcreate == "1") && ( ($onlyregcancreate == "1" && is_user($user)) || ($onlyregcancreate == "0") ) ) {
?>
<BR>
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0" WIDTH="100%" VALIGN="TOP">
  <TR><TD BGCOLOR="<?=$bgcolor2?>">
  <TABLE BORDER="0" CELLPADDING="4" CELLSPACING="1" WIDTH="100%">
    <TR BGCOLOR="<?=$bgcolor2?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD COLSPAN="5"><FONT CLASS="newstitle"><STRONG><?=_WCCREATEAROOM?></STRONG></FONT></TD>
    </TR>
    <TR BGCOLOR="<?=$bgcolor3?>" VALIGN="MIDDLE">
      <TD ALIGN="LEFT"><FONT CLASS="pn-normal"><STRONG><?=_WCROOMNAME?>*</STRONG></FONT></TD>
      <TD ALIGN="LEFT"><FONT CLASS="pn-normal"><STRONG><?=_WCROOMDESC?>*</STRONG></FONT></TD>
      <TD ALIGN="CENTER"><FONT CLASS="pn-normal"><STRONG><?=_WCROOMTYPE?></STRONG></FONT></TD>
      <TD ALIGN="LEFT"><FONT CLASS="pn-normal"><STRONG><?=_WCPASSWORD?>**</STRONG></FONT></TD>
      <TD ALIGN="CENTER"><FONT CLASS="pn-normal"><STRONG><?=_WCACTION?></STRONG></FONT></TD>
    </TR>
    <form action="modules.php" method="post">
    <input type="hidden" name="name" value="<?=$ModName?>">
    <input type="hidden" name="file" value="index">
    <input type="hidden" name="op" value="modload">
    <input type="hidden" name="action" value="ADDROOM">

    <tr bgcolor="<?=$bgcolor1?>">
      <td align="left">
        <input name="rname" value="" size="15">
      </td>
      <td align="left">
        <input name="descript" value="" size="30">
      </td>
      <td align="center">
        <select name="typ">
          <option value="N"><?=_WCNORMROOM?></option>
          <?
          if(is_user($user))
            echo '<option value="P">'._WCPRIVROOM.'</option>';
          ?>
        </select>
      </td>
      <td align="left">
        <?
        if(is_user($user))
          echo '<input name="pass" value="" size="10">';
        ?>
      </td>
      <td align="center">
        <input type="submit" name="submit" value="<?=_WCADD?>">
      </td>
    </tr>
    </form>
    <tr bgcolor="<?=$bgcolor1?>">
      <td colspan="5"><font class="pn-sub"><?=_WCREQFIELDS.'&nbsp;&nbsp;&nbsp;&nbsp;'._WCPASSOPT ?></font></td>
    </tr>
  </TABLE>
  </TD></TR>
</TABLE>
<?    
  }
  if(isset($errmsg))
    echo "<P><STRONG>$errmsg</STRONG></P>";
  if(is_admin($admin))
    // we got an admin here, display the admin option
    echo "<FONT CLASS=pn-normal><BR><CENTER><a href=\"modules.php?op=modload&name=".$ModName."&file=admin\">"._WCADMINMENU."</a></CENTER>"; 
  CloseTable();
  include "modules/$ModName/wc_footer.php";
}

function join_room($roomid,$pass,$username,$uid) {
  global $prefix, $ModName, $user, $sitename, $pnconfig, $currentlang, $usertime;
  unset($errmsg);
  $sql = "SELECT rid, name, typ, pass, descript FROM ".$prefix."_chatroom WHERE rid = $roomid";
  $row = mysql_fetch_array(mysql_query($sql));
  if($row[typ] == "P") {
    if(is_user($user)) {
      if($row[pass] != "" && !isset($pass)) {
        OpenTable();
        include "modules/$ModName/wc_header.php";
        OpenTable();
        echo "<form action=\"modules.php?op=modload&name=".$ModName."&file=index\" method=\"post\">";
        echo "<CENTER><B>$row[name]</B> <img src=\"modules/$ModName/images/pass.gif\" alt=\""._WCPWREQ."\"> "._WCENTERPW.": ";
        echo "<INPUT TYPE=\"password\" SIZE=\"10\" NAME=\"pass\" MAXLENGTH=\"20\">&nbsp;&nbsp;";
        echo "<input type=\"hidden\" name=\"roomid\" value=\"$roomid\">";
        echo "<input type=\"submit\" value=\""._WCJOINROOM."\">"; 
        CloseTable();
        echo "<BR><BR><CENTER><a href=\"modules.php?op=modload&name=".$ModName."&file=index\">"._WCBACKLIST."</a></center>";
        CloseTable();
        include "modules/$ModName/wc_footer.php";
        include 'footer.php';
        exit;
      } else if(isset($pass)) {
        if($pass != $row[pass]) {
          $errmsg = sprintf(_WCINVROOMPW,$row[name]);
          disp_index($errmsg);
          include 'footer.php';
          exit;
        }
      }
    } else {
      $errmsg = sprintf(_WCREGONLY,$row[name]);
      disp_index($errmsg);
      include 'footer.php';
      exit;
    }
  } else {
    if($username == ""){
      OpenTable();
      include "modules/$ModName/wc_header.php";
      OpenTable();
      echo "<form action=\"modules.php?op=modload&name=".$ModName."&file=index\" method=\"post\">";
      echo "<CENTER><B>$row[name]</B><BR>$row[descript]<BR><BR>";
      echo _WCENTERUNAME.": <INPUT TYPE=\"text\" SIZE=\"10\" NAME=\"wcusername\" MAXLENGTH=\"10\" VALUE=\"$username\">&nbsp;&nbsp;";
      echo "<input type=\"hidden\" name=\"roomid\" value=\"$roomid\">";
      echo "<input type=\"submit\" value=\""._WCJOINROOM."\">"; 
      CloseTable();
      echo "<BR><BR><CENTER><a href=\"modules.php?op=modload&name=".$ModName."&file=index\">"._WCBACKLIST."</a></center>";
      CloseTable();
      include "modules/$ModName/wc_footer.php";
      include 'footer.php';
      exit;
    } else {
      if(!isset($uid)){
        $q = mysql_query("select uid from ".$prefix."_chatuser where uid < 0 order by uid asc");
        if(mysql_num_rows($q) == 0)
          $uid = -1;
        else {
          $res = mysql_fetch_array($q);
          $uid = $res[uid] - 1;
        }
      }
    }
  }
  // we'll just cover up blanks for chat so cmds will werk
  $username = strtr($username, " ", "_");
  // let's get the user into the room after the following prelims
  $ip = getenv("REMOTE_ADDR");
  $q = mysql_query("select u.name, u.uid, u.ip, r.name from ".$prefix."_chatuser as u left join ".$prefix."_chatroom as r on u.rid = r.rid where u.name='$username' or u.ip='$ip'");
  list($u_name, $u_id, $u_ip, $r_name) = mysql_fetch_array($q);
  if(mysql_num_rows($q) != 0)
    $errmsg = sprintf(_WCALREADYINROOM, $u_name, $r_name, $usertime);
  else {
	  $q = mysql_query("insert into ".$prefix."_chatmessage values (".time().", $roomid, 0, 0,'USERENTER', '$username')");
    $q = mysql_query("insert into ".$prefix."_chatuser values ($uid, '$username', ".time().", $roomid, '$ip')");
    // if we got a logged in user here, get their tz info
    if(is_user($user)) {
      $userinfo = getusrinfo($user);
      $tz = doubleval($userinfo[timezone_offset]) - doubleval($pnconfig[timezone_offset]);
    }
    $chatroom = addslashes($row[name]);
    echo "<script>window.open('modules/$ModName/chat.php?chatroom=$chatroom&rid=$roomid&uid=$uid&username=$username&tz=$tz&lang=$currentlang&first=1','','width=650,height=400,resizable=yes,toolbar=no,location=no,directories=no,status=no');</script>";
  }
  disp_index($errmsg);
}

include 'header.php';
if($action == "ADDROOM") {
  if($rname != "" && $descript != "")
    $q = mysql_query("insert into ".$prefix."_chatroom values (null, '$rname', '$descript', '$typ', '$pass', '0')");
  else
    $errmsg = _WCFILLFIELDS;
}
if(isset($roomid)) {
  if(is_user($user)) {
    $userinfo = getusrinfo($user);
    $wcusername = $userinfo[uname];
    $uid = $userinfo[uid];
  }
  join_room($roomid,$pass,$wcusername,$uid);
} else {
  disp_index($errmsg);
}
include 'footer.php';
?>
