<?
/*****************************************************************************************
 *  WebChat - multiple private/open room chat system for PostNuke                        *
 *****************************************************************************************
 *   David "Cyklone" Thompson   david@thompsonville.net                                  *
 *   portions credited to Daniel Toma [dt@dnt.ro] [http://www.webdev.ro]                 *
 *****************************************************************************************
 *  Read CHANGELOG for updates and bug fixes                                             *
 *****************************************************************************************
 * POST-NUKE Content Management System                                                   *
 * Copyright (C) 2001 by the Post-Nuke Development Team.                                 *
 * http://www.postnuke.com/                                                              *
 * --------------------------------------------------------------------------------------*
 * Based on:                                                                             *
 * PHP-NUKE Web Portal System - http://phpnuke.org/                                      *
 * Thatware - http://thatware.org/                                                       *
 *****************************************************************************************/

if (!eregi('modules.php', $PHP_SELF)) 
  die ("You can't access this file directly...");

$ModName = $GLOBALS[name];
//$ModName = basename( dirname( __FILE__ ) );

if(file_exists("modules/$ModName/language/lang-".$currentlang.".php")) {
	include("modules/$ModName/language/lang-".$currentlang.".php");
}
else {
	include("modules/$ModName/language/lang-english.php");
}


function settings_menu() {
  global $ModName, $bgcolor1, $bgcolor2, $bgcolor3, $prefix, $dbhost,
         $dbuname, $dbname, $dbpass;
  //require "modules/$ModName/inc/config.php";
  if($dbhost == '') {
    global $pnconfig;
    $dbhost  = $pnconfig[dbhost];
    $dbuname = $pnconfig[dbuname];
    $dbpass  = $pnconfig[dbpass];
    $dbname  = $pnconfig[dbname];
  }  
  OpenTable();
?>
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0" WIDTH="100%" VALIGN="TOP">
  <TR><TD BGCOLOR="<?=$bgcolor2?>">
  <TABLE BORDER="0" CELLPADDING="4" CELLSPACING="1" WIDTH="100%">
    <TR BGCOLOR="<?=$bgcolor2?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD COLSPAN="6"><FONT CLASS="newstitle"><STRONG><?=_WCINSGENSETTINGS?></STRONG></FONT></TD>
    </TR>
    <TR BGCOLOR="<?=$bgcolor3?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD COLSPAN="6"><FONT CLASS="newstitle"><?=_WCADMINGENMSG1?></FONT></TD>
    </TR>
    <form action="modules.php" method="post">
    <input type="hidden" name="name" value="<?=$ModName?>">
    <input type="hidden" name="file" value="install">
    <input type="hidden" name="op" value="modload">
    <input type="hidden" name="action" value="SAVESETTINGS">
<?
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINDBHOST."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xdbhost\" size=20 value=\"$dbhost\" readonly></TD></TR>";
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINDBUNAME."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xdbuname\" size=20 value=\"$dbuname\" readonly></TD></TR>";
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINDBPW."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xdbpass\" size=20 value=\"$dbpass\" readonly></TD></TR>";
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINDBNAME."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xdbname\" size=20 value=\"$dbname\" readonly></TD></TR>";
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINDBPREFIX."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xprefix\" size=20 value=\"$prefix\" readonly></TD></TR>";
?>
    <TR BGCOLOR="<?=$bgcolor3?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD COLSPAN="6"><FONT CLASS="newstitle"><?=_WCADMINGENMSG2?></FONT></TD>
    </TR>
<?
  $set_allowcreate[1] = 'checked';
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCALLOWCREATE."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"radio\" name=\"xallowcreate\" value=\"1\" $set_allowcreate[1]>"._WCYES."&nbsp;<INPUT TYPE=\"radio\" name=\"xallowcreate\" value=\"0\" $set_allowcreate[0]>"._WCNO."</TD></TR>";
  $set_onlyregcancreate[0] = 'checked';
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCONLYREGCANCREATE."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"radio\" name=\"xonlyregcancreate\" value=\"1\" $set_onlyregcancreate[1]>"._WCYES."&nbsp;<INPUT TYPE=\"radio\" name=\"xonlyregcancreate\" value=\"0\" $set_onlyregcancreate[0]>"._WCNO."</TD></TR>";
  $msg_refresh = 10000;
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINMSGREFRESH."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xmsg_refresh\" size=\"10\" value=\"$msg_refresh\"></TD></TR>";
  $usertime = 180;
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINUSRTIME."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xusertime\" size=\"10\" value=\"$usertime\"></TD></TR>";
  $set_showsmiles[1] = 'checked';
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINSHOWSMILES."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"radio\" name=\"xshowsmiles\" value=\"1\" $set_showsmiles[1]>"._WCYES."&nbsp;<INPUT TYPE=\"radio\" name=\"xshowsmiles\" value=\"0\" $set_showsmiles[0]>"._WCNO."</TD></TR>";
  $smilesdir = "images/smiley";
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINSMILESDIR."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xsmilesdir\" size=\"20\" value=\"$smilesdir\"></TD></TR>";
  $set_usesounds[1] = 'checked';
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINUSESOUNDS."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"radio\" name=\"xusesounds\" value=\"1\" $set_usesounds[1]>"._WCYES."&nbsp;<INPUT TYPE=\"radio\" name=\"xusesounds\" value=\"0\" $set_usesounds[0]>"._WCNO."</TD></TR>";
  $set_showsounds[0] = 'checked';
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINSHOWSOUNDS."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"radio\" name=\"xshowsounds\" value=\"1\" $set_showsounds[1]>"._WCYES."&nbsp;<INPUT TYPE=\"radio\" name=\"xshowsounds\" value=\"0\" $set_showsounds[0]>"._WCNO."</TD></TR>";
  $soundsdir = "sounds";
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINSNDSDIR."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xsoundsdir\" size=\"20\" value=\"$soundsdir\"></TD></TR>";
  $set_showusers[1] = 'checked';
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINSHOWUSRS."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"radio\" name=\"xshowusers\" value=\"1\" $set_showusers[1]>"._WCYES."&nbsp;<INPUT TYPE=\"radio\" name=\"xshowusers\" value=\"0\" $set_showusers[0]>"._WCNO."</TD></TR>";
  $set_keeponline[0] = 'checked';
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINKEEPONLINE."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"radio\" name=\"xkeeponline\" value=\"1\" $set_keeponline[1]>"._WCYES."&nbsp;<INPUT TYPE=\"radio\" name=\"xkeeponline\" value=\"0\" $set_keeponline[0]>"._WCNO."</TD></TR>";
?>
  </TABLE>
  </TD></TR>
</TABLE>
<?
  CloseTable();
  print "<br><center><input type=\"submit\" value=\""._WCINSSAVESETTINGS."\"></center></form>";
  CloseTable();
include 'footer.php';
}

function save_settings($vars) {
global $ModName;

	if(!$fp = fopen("modules/$ModName/inc/config.php",'w')) {
	  $errormsg = _WCSETTINGSERR;
    return $errormsg;
	}
  $config_header[] = "<?\n";
  $config_header[] = "/****************************************************************************************\n";
  $config_header[] = " * WebChat config file                                                                  *\n";
  $config_header[] = " *   This file is edited thru the WebChat Administration, DO NOT EDIT HERE!!            *\n";
  $config_header[] = " *   If edited here, it may not correctly read when editing thru the admin interface.   *\n";
  $config_header[] = " ****************************************************************************************/\n";
  $config_vars = array(
    'dbhost'            => $vars[xdbhost],
    'dbuname'           => $vars[xdbuname],
    'dbpass'            => $vars[xdbpass],
    'dbname'            => $vars[xdbname],
    'prefix'            => $vars[xprefix],
    'allowcreate'       => $vars[xallowcreate],
    'onlyregcancreate'  => $vars[xonlyregcancreate],
    'msg_refresh'       => $vars[xmsg_refresh],
    'usertime'          => $vars[xusertime],
    'showsmiles'        => $vars[xshowsmiles],
    'smilesdir'         => $vars[xsmilesdir],
    'usesounds'         => $vars[xusesounds],
    'showsounds'        => $vars[xshowsounds],
    'soundsdir'         => $vars[xsoundsdir],
    'showusers'         => $vars[xshowusers],
    'keeponline'        => $vars[xkeeponline]);
    
	if(phpversion() >= '4.0.0') { // php4+
		foreach($config_vars as $k=>$v) {
			$config_header[] = "\$$k = '$v';\n";
		}
	}
	else { // php3
		while(list($k, $v) = each($config_vars)) {
			$config_header[] = "\$$k = '$v';\n";
		}
	}
	
	$config_header[] = '?>';

	fwrite($fp, implode($config_header,''));
	fclose($fp);
	$errormsg = _WCSETTINGSSAVED;
  return $errormsg;
}

function make_tables() {
  global $prefix, $ModName;
  
  echo "<p align=\"left\"><p align=\"left\"><font class=\"pn-sub\">"._WCINSCREATETABLES."</font></p>";
  
  echo "<p align=\"left\"><font class=\"pn-sub\"><strong>"._WCINSCONFIGSAVED."</strong></font></p>";
  $q = mysql_query("CREATE TABLE ".$prefix."_chatuser (uid integer primary key, name varchar(20), last int(11), rid integer, ip varchar(16))") or die ("<b>"._WCINSTABLEERR." ".$prefix."_chatuser!</b>");
  echo "<p align=\"left\"><font class=\"post-sub\">".$prefix."_chatuser "._WCINSTABLECREATED."</font></p>";
  $q = mysql_query("CREATE TABLE ".$prefix."_chatroom (rid integer auto_increment primary key, name varchar(20), descript varchar(255), typ varchar(1), pass varchar(64), orig tinyint(1))") or die ("<b>"._WCINSTABLEERR." ".$prefix."_chatroom!</b>");
  echo "<p align=\"left\"><font class=\"post-sub\">".$prefix."_chatroom "._WCINSTABLECREATED."</font></p>";
  $q = mysql_query("CREATE TABLE ".$prefix."_chatmessage (time int(11), rid integer, send_id integer, rcpt_id integer, cmd varchar(50), message text)") or die ("<b>"._WCINSTABLEERR." ".$prefix."_chatmessage!</b>");
  echo "<p align=\"left\"><font class=\"post-sub\">".$prefix."_chatmessage "._WCINSTABLECREATED."</font></p>";
  $q = mysql_query("CREATE TABLE ".$prefix."_chatsmile (sid integer auto_increment primary key, code varchar(12), file varchar(50), emotion varchar(50), showit tinyint(1) default '0')") or die ("<b>"._WCINSTABLEERR." ".$prefix."_chatsmile!</b>");
  echo "<p align=\"left\"><font class=\"post-sub\">".$prefix."_chatuser "._WCINSTABLECREATED."</font></p>";
  $q = mysql_query("CREATE TABLE ".$prefix."_chatsound (sid integer auto_increment primary key, cmd varchar(50), file varchar(50), saytext varchar(50))") or die ("<b>"._WCINSTABLEERR." ".$prefix."_chatsound!</b>");
  echo "<p align=\"left\"><font class=\"post-sub\">".$prefix."_chatsound "._WCINSTABLECREATED."</font></p>";
?>
  <form action="modules.php" method="post">
  <input type="hidden" name="name" value="<?=$ModName?>">
  <input type="hidden" name="file" value="install">
  <input type="hidden" name="op" value="modload">
  <input type="hidden" name="action" value="TABLESCREATED">
  <br><center><input type="submit" value="<?=_WCINSCONT ?>"></center>
  </form>
<?
}

function add_defaults() {
  global $prefix, $ModName;
  
  echo "<p align=\"left\"><p align=\"left\"><font class=\"pn-sub\">"._WCINSADDINGDEF."</font></p>";

  echo "<p align=\"left\"><p align=\"left\"><font class=\"pn-sub\">"._WCINSADDINGROOMS."</font></p>";
	$q = mysql_query("INSERT INTO ".$prefix."_chatroom VALUES (null, 'General', 'General chat room', 'N', '', '1')") or die ("<b>".sprintf(_WCINSADDINGDONE,$prefix."_chatroom")."</b>");
  echo "<p align=\"left\"><p align=\"left\"><font class=\"pn-sub\">".sprintf(_WCINSADDINGDONE,$prefix."_chatroom")."</font></p>";

  echo "<p align=\"left\"><p align=\"left\"><font class=\"pn-sub\">"._WCINSADDINGSMILES."</font></p>";
	$q = mysql_query("INSERT INTO ".$prefix."_chatsmile VALUES (null, ':)', 'smile.gif', 'Smile', '1')") or die ("<b>".sprintf(_WCINSADDINGDONE,$prefix."_chatsmile")."</b>");
	$q = mysql_query("INSERT INTO ".$prefix."_chatsmile VALUES (null, ':(', 'sad.gif', 'Sad', '1')") or die ("<b>".sprintf(_WCINSADDINGDONE,$prefix."_chatsmile")."</b>");
	$q = mysql_query("INSERT INTO ".$prefix."_chatsmile VALUES (null, ';)', 'wink.gif', 'Wink', '1')") or die ("<b>".sprintf(_WCINSADDINGDONE,$prefix."_chatsmile")."</b>");
	$q = mysql_query("INSERT INTO ".$prefix."_chatsmile VALUES (null, ':D', 'biggrin.gif', 'Big grin', '1')") or die ("<b>".sprintf(_WCINSADDINGDONE,$prefix."_chatsmile")."</b>");
  echo "<p align=\"left\"><p align=\"left\"><font class=\"pn-sub\">".sprintf(_WCINSADDINGDONE,$prefix."_chatsmile")."</font></p>";

  echo "<p align=\"left\"><p align=\"left\"><font class=\"pn-sub\">"._WCINSADDINGSOUNDS."</font></p>";
	$q = mysql_query("INSERT INTO ".$prefix."_chatsound VALUES (null, 'hey', 'hey.wav', 'saying hey')") or die ("<b>".sprintf(_WCINSADDINGDONE,$prefix."_chatsound")."</b>");
  echo "<p align=\"left\"><p align=\"left\"><font class=\"pn-sub\">".sprintf(_WCINSADDINGDONE,$prefix."_chatsound")."</font></p>";

  echo "<p align=\"left\"><font class=\"pn-sub\">"._WCINSDONETXT."</font></p>";
?>
  <form action="modules.php" method="post">
  <input type="hidden" name="name" value="<?=$ModName?>">
  <input type="hidden" name="file" value="install">
  <input type="hidden" name="op" value="modload">
  <input type="hidden" name="action" value="DONE">
  <br><center><input type="submit" value="<?=_WCINSDONE ?>"></center>
  </form>
<?  
}

/***************************** main *****************************/

include 'header.php';
OpenTable();
include "modules/$ModName/wc_header.php";

if(!is_admin($admin))
  $errormsg = _WCADMINNEEDED;
  
if(isset($errormsg))
  echo "<p align=\"left\"><font class=\"pn-normal\"><strong>$errormsg</strong></font></p>";
else {
  //if(isset($action)) {
    switch($action) {
      case "SAVESETTINGS":
        if(save_settings($GLOBALS[HTTP_POST_VARS]) != _WCSETTINGSSAVED) {
          $errormsg = _WCSETTINGSERR;
          break;
        }
        make_tables();
        break;
      case "TABLESCREATED":
        add_defaults();
        break;
      case "DONE":
        unlink(dirname($HTTP_SERVER_VARS[SCRIPT_FILENAME])."/modules/$ModName/install.php");
        echo "<p align=\"center\"><font class=\"pn-sub\">"._WCINSTALLED."</font></p>";
        break;
      default:
        settings_menu();  
    }
  //}
}
  
CloseTable();
include "modules/$ModName/wc_footer.php";
include 'footer.php';
?>
