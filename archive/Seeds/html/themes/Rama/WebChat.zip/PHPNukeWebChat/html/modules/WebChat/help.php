<?
/*****************************************************************************************
 *  WebChat - multiple private/open room chat system for PostNuke                        *
 *****************************************************************************************
 *   David "Cyklone" Thompson   david@thompsonville.net                                  *
 *   portions credited to Daniel Toma [dt@dnt.ro] [http://www.webdev.ro]                 *
 *****************************************************************************************
 *  Read CHANGELOG for updates and bug fixes                                             *
 *****************************************************************************************
 * POST-NUKE Content Management System                                                   *
 * Copyright (C) 2001 by the Post-Nuke Development Team.                                 *
 * http://www.postnuke.com/                                                              *
 * --------------------------------------------------------------------------------------*
 * Based on:                                                                             *
 * PHP-NUKE Web Portal System - http://phpnuke.org/                                      *
 * Thatware - http://thatware.org/                                                       *
 *****************************************************************************************/

  require("./inc/config.php");
  require("./inc/mysql.lib.php");
  
  $DbLink = new DB($dbhost, $dbname, $dbuname, $dbpass);

  // pull in proper language    
  if(file_exists("language/lang-$lang.php"))
    include("language/lang-$lang.php");
  else
    include("language/lang-english.php");
?>
<html>
<head>
<title><?=_WCHELPTITLE ?></title>
<link rel="stylesheet" href="main.css" type="text/css">
</head>
<body bgcolor="#EEEEFF">
<A NAME="top">
<?
  echo "<p align=\"center\"><font class=\"title\">"._WCHELPTITLE."</font></p>";
  echo "<p align=\"left\"><font class=\"normal\">� <a href=\"#smilies\">"._WCHELPTEXT1."</a>";
  echo "<br>� <a href=\"#sounds\">"._WCHELPTEXT2."</a>";
  echo "<br>� <a href=\"#commands\">"._WCHELPTEXT3."</a></font></p>";
?>
<A NAME="smilies">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0" WIDTH="100%" VALIGN="TOP">
  <TR><TD BGCOLOR="#000000">
  <TABLE BORDER="0" CELLPADDING="4" CELLSPACING="1" WIDTH="100%">
    <TR BGCOLOR="#C0C0C0" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD COLSPAN="5" ALIGN="CENTER"><FONT CLASS="normal"><STRONG><?=_WCHELPSMILETBL?></STRONG></FONT></TD>
    </TR>
    <TR BGCOLOR="lightblue" VALIGN="MIDDLE">
      <TD ALIGN="CENTER"><FONT CLASS="normal"><STRONG><?=_WCSMILEIMAGE ?></STRONG></FONT></TD>
      <TD ALIGN="CENTER"><FONT CLASS="normal"><STRONG><?=_WCSMILECODE ?></STRONG></FONT></TD>
      <TD ALIGN="LEFT"><FONT CLASS="normal"><STRONG><?=_WCSMILEEMOTION ?></STRONG></FONT></TD>
    </TR>
<?
  $DbLink->query("select code, file, emotion from ".$prefix."_chatsmile");
  if($DbLink->num_rows() > 0) {
    while(list($smilecode, $smilefile, $smileemotion) = $DbLink->next_record()) {
      echo "<TR BGCOLOR=\"#FFFFFF\">";
      echo "<TD ALIGN=\"center\"><img src=\"$smilesdir/$smilefile\" border=\"0\"></TD><TD ALIGN=\"center\"><FONT class=\"normal\">$smilecode</FONT></TD><TD ALIGN=\"left\"><FONT class=\"normal\">$smileemotion</FONT></TD></TR>";
    }
  } else  
    echo "<TR BGCOLOR=\"#FFFFFF\"><TD COLSPAN=\"3\" ALIGN=\"center\">".sprintf(_WCHELPNODATA,"smileys")."</TD><TD ALIGN=\"center\"><FONT class=\"normal\">$smilecode</FONT></TD><TD ALIGN=\"left\"><FONT class=\"normal\">$smileemotion</FONT></TD></TR>";
  $DbLink->clean_results();
?>
  </TABLE>
  </TD></TR>
</TABLE>
<BR>
<A NAME="sounds">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0" WIDTH="100%" VALIGN="TOP">
  <TR><TD BGCOLOR="#000000">
  <TABLE BORDER="0" CELLPADDING="4" CELLSPACING="1" WIDTH="100%">
    <TR BGCOLOR="#C0C0C0" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD COLSPAN="5" ALIGN="CENTER"><FONT CLASS="normal"><STRONG><?=_WCHELPSOUNDTBL?></STRONG></FONT></TD>
    </TR>
    <TR BGCOLOR="lightblue" VALIGN="MIDDLE">
      <TD ALIGN="LEFT"><FONT CLASS="normal"><STRONG><?=_WCSOUNDCMD ?></STRONG></FONT></TD>
      <TD ALIGN="LEFT"><FONT CLASS="normal"><STRONG><?=_WCSOUNDTEXT ?></STRONG></FONT></TD>
    </TR>
<?
  $DbLink->query("select cmd, saytext from ".$prefix."_chatsound");
  if($DbLink->num_rows() > 0) {
    while(list($soundcmd, $soundsaytext) = $DbLink->next_record()) {
      echo "<TR BGCOLOR=\"#FFFFFF\">";
      echo "<TD ALIGN=\"left\"><FONT class=\"normal\">/$soundcmd</FONT></TD><TD ALIGN=\"left\"><FONT class=\"normal\">$soundsaytext</FONT></TD></TR>";
    }
  } else 
    echo "<TR BGCOLOR=\"#FFFFFF\"><TD COLSPAN=\"2\" ALIGN=\"center\">".sprintf(_WCHELPNODATA,"sounds")."</TD><TD ALIGN=\"center\"><FONT class=\"normal\">$smilecode</FONT></TD><TD ALIGN=\"left\"><FONT class=\"normal\">$smileemotion</FONT></TD></TR>";
  echo "<TR BGCOLOR=\"lightblue\"><TD COLSPAN=\"2\" ALIGN=\"left\"><FONT class=\"normal\">"._WCHELPSOUNDTBLOPTS."</FONT></TD></TR>";
  $DbLink->clean_results();
?>
  </TABLE>
  </TD></TR>
</TABLE>
<BR>
<A NAME="commands">
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0" WIDTH="100%" VALIGN="TOP">
  <TR><TD BGCOLOR="#000000">
  <TABLE BORDER="0" CELLPADDING="4" CELLSPACING="1" WIDTH="100%">
    <TR BGCOLOR="#C0C0C0" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD COLSPAN="5" ALIGN="CENTER"><FONT CLASS="normal"><STRONG><?=_WCHELPCMDTBL?></STRONG></FONT></TD>
    </TR>
    <TR BGCOLOR="lightblue" VALIGN="MIDDLE">
      <TD ALIGN="LEFT"><FONT CLASS="normal"><STRONG><?=_WCSOUNDCMD ?></STRONG></FONT></TD>
      <TD ALIGN="LEFT"><FONT CLASS="normal"><STRONG><?=_WCHELPCMDDESC ?></STRONG></FONT></TD>
    </TR>
    <TR BGCOLOR="#FFFFFF">
      <TD ALIGN="left"><FONT class="normal">/msg <i>username</i></FONT></TD>
      <TD ALIGN="left"><FONT class="normal"><?=_WCHELPCMDMSGHLP ?></i></FONT></TD>
    </TR>
  </TABLE>
  </TD></TR>
</TABLE>
<?
  $DbLink->close();
?>
<font class="normal">
<p align="center"><a href="#top"><?=_WCHELPTOP ?></a><br><br>
<a href="javascript:window.close();"><?=_WCHELPCLOSE ?></a></p>
</font>
</body>
</html>