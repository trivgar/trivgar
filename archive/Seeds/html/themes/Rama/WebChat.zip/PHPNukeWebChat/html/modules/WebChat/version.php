<?php
/*****************************************************************************************
 *  WebChat - multiple private/open room chat system for PostNuke                        *
 *****************************************************************************************
 *   David "Cyklone" Thompson   david@thompsonville.net                                  *
 *   portions credited to Daniel Toma [dt@dnt.ro] [http://www.webdev.ro]                 *
 *****************************************************************************************
 *  Read CHANGELOG for updates and bug fixes                                             *
 *****************************************************************************************
 * POST-NUKE Content Management System                                                   *
 * Copyright (C) 2001 by the Post-Nuke Development Team.                                 *
 * http://www.postnuke.com/                                                              *
 * --------------------------------------------------------------------------------------*
 * Based on:                                                                             *
 * PHP-NUKE Web Portal System - http://phpnuke.org/                                      *
 * Thatware - http://thatware.org/                                                       *
 *****************************************************************************************/

$modversion['name'] = 'WebChat';
$modversion['version'] = '0.6';
$modversion['description'] = 'A module for multiple chat rooms';
$modversion['credits'] = 'docs/credits';
$modversion['help'] = 'docs/install';
$modversion['changelog'] = 'docs/changelog';
$modversion['license'] = 'docs/license';
$modversion['official'] = 0;
$modversion['author'] = 'David "Cyklone" Thompson';
$modversion['contact'] = 'http://naturald.sytes.net';
$modversion['admin'] = 0;
$modversion['adapted'] = 'Frank Wallacher - Saarport.NET';
$modversion['adlink'] = 'http://www.saarport.net';

?>