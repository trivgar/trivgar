<?
/*****************************************************************************************
 *  WebChat - multiple private/open room chat system for PostNuke                        *
 *****************************************************************************************
 *   David "Cyklone" Thompson   david@thompsonville.net                                  *
 *   portions credited to Daniel Toma [dt@dnt.ro] [http://www.webdev.ro]                 *
 *****************************************************************************************
 *  Read CHANGELOG for updates and bug fixes                                             *
 *****************************************************************************************
 * POST-NUKE Content Management System                                                   *
 * Copyright (C) 2001 by the Post-Nuke Development Team.                                 *
 * http://www.postnuke.com/                                                              *
 * --------------------------------------------------------------------------------------*
 * Based on:                                                                             *
 * PHP-NUKE Web Portal System - http://phpnuke.org/                                      *
 * Thatware - http://thatware.org/                                                       *
 * --------------------------------------------------------------------------------------*
 * Traducci�n al castellano:                                                             *                *
 * Xavi Gil - http://www.comadronas.org  - dgil@tinet.org                                *
 *****************************************************************************************/

// Main
define('_WCAPPNAME',          'WebChat');
define('_WCTITLE',            '%s '._WCAPPNAME);
define('_WCNOTINSTALLED',     _WCAPPNAME.' no esta instalado o ha habido un problema con la instalaci�n.<br><br>Clica <a href="modules.php?op=modload&name=WebChat&file=install">aqui</a> para empezar la instalaci�n');
define('_WCADMINNEEDED',      'Por favor, entra como administrador para poder ejecutar la instalaci�n '._WCAPPNAME.' est� activada!');
define('_WCNOACTIVE',         'No hay salas creadas');
define('_WCBACKLIST',         'Volver al listado de salas');
define('_WCINVALIDROOM',      'Has seleccionado una sala invalida. Vuelve atras y selecciona otra');
define('_WCNONICK',           'No has introducido tu nickname');
define('_WCPWREQROOM',        'Se necesita un password para acceder a esta sala');
define('_WCINVUSERPW',        'Username y/o password son incorrectos');
define('_WCROOMNAME',         'Nombre de la sala');
define('_WCROOMTYPE',         'Tipo');
define('_WCROOMDESC',         'Descripci�n');
define('_WCROOMOCCUPANTS',    'Ocupantes');
define('_WCPASSWORD',         'Password');
define('_WCACTION',           'Acci�n');
define('_WCNORMROOM',         'Normal');
define('_WCPRIVROOM',         'Privada');
define('_WCENTERUNAME',       'Entra tu nombre de usuario');
define('_WCINVROOMPW',        'Password incorrecto para %s');
define('_WCREGONLY',          '%s es solo para usuarios registrados');
define('_WCALREADYINROOM',    'Se ha encontrado otro usuario con el mismo nombre y IP que tu ( %s ) en la sala %s .<br>Nuestros registros se limipiaran en %s segundos, intentalo entonces.');
define('_WCUSERENTER',        '%s ha entrado en el chat');
define('_WCPWREQ',            'Password necesario');
define('_WCENTERPW',          'Entra el password');
define('_WCUSERS',            'usuario');
define('_WCJOINROOM',         'Entrar en la Sala');
define('_WCCHATTIPS',         'Truco: pon el texto entre asteriscos <b>*</b> para <b>negrita</b>, y entre subrayados <b>_</b> para <i>cursiva</i>');
define('_WCFILLFIELDS',       'Por favor, rellena los campos requeridos');
define('_WCREQFIELDS',        '* = Campo requerido');
define('_WCPASSOPT',          '** = Solo valido para Salas Privadas');
define('_WCCHATWELCOME',      'Bienvenido, se respetuoso y claro en tus comentarios');
define('_WCQUIT',             'Gracias por usar '._WCAPPNAME.', vuelve pronto.');
define('_WCQUITREASON0',      '%s, has abandonado la sala %s.');
define('_WCQUITREASON1',      '%s, has sido expulsado de %s porque no estaba registrado!');

// Admin 
define('_WCADMINMENU',        _WCAPPNAME.' Administraci�n');
define('_WCADMINGEN',         'Configuraci�n General');
define('_WCADMINROOMS',       'Configuraci�n Salas');
define('_WCADMINSMILES',      'Configuraci�n Smiley');
define('_WCADMINSOUNDS',      'Configuraci�n Sonidos');
define('_WCADMINSPECIAL',     'Funciones Especiales');
define('_WCADMINDBHOST',      'DB Host (solo lectura)');
define('_WCADMINDBUNAME',     'DB Username (solo lectura)');
define('_WCADMINDBPW',        'DB Password (solo lectura)');
define('_WCADMINDBNAME',      'DB Name (solo lectura)');
define('_WCADMINDBPREFIX',    'DB Prefix (solo lectura)');
define('_WCADMINSMILE',       'Smilies');
define('_WCADD',              'A�adir');
define('_WCMODIFY',           'Modificar');
define('_WCDELETE',           'Borrar');
define('_WCNOTEMPTY',         'No puedes borrar la sala. Expulsa primero a los usuarios');
define('_WCADMINROOMSDESC',   'Crear, modificar y borrar salas');
define('_WCADMINGENDESC',     'Configurar aspectos generales del WebChat');
define('_WCADMINSPECIALDESC', 'Mensajes para todas las salas y usuarios (no implementado aun)');
define('_WCADMINSMILEDESC',   'A�adir, editar y borrar smilies');
define('_WCADMINSOUNDDESC',   'A�adir, editar y borrar sonidos');
define('_WCADMINMSGREFRESH',  'Tiempo de refresco de los mensajes (milisegundos)');
define('_WCADMINUSRTIME',     'Usuario/mensajes (seg.)');
define('_WCADMINSHOWSMILES',  'Mostrar acceso abreviado a los smiley');
define('_WCADMINSMILESDIR',   'Directorio de los Smilies');
define('_WCADMINUSESOUNDS',   'Usar sonidos');
define('_WCADMINSHOWSOUNDS',  'Mostrar acceso abreviado a los sonidos (no implementado aun)');
define('_WCADMINSNDSDIR',     'Directorio de sonidos');
define('_WCADMINSHOWUSRS',    'Mostrar lista de usuarios');
define('_WCADMINKEEPONLINE',  'Dejar la sesi�n activa en el sitio');
define('_WCADMINGENMSG1',     'WebChat necesita acceso a tu base de datos (los datos se han extraido de su configuracion de PhpNuke)');
define('_WCADMINGENMSG2',     'Configuraci�n general de la ventana del WebChat');
define('_WCADMINCURSMILEDIR', 'Directorio actual de los Smiley ');
define('_WCADMINCURSOUNDDIR', 'Directorio actual de los Sonidos');
define('_WCSMILEID',          'SID');
define('_WCSMILEIMAGE',       'Imagen');
define('_WCSMILECODE',        'C�digo');
define('_WCSMILEFILE',        'Nombre del fichero');
define('_WCSMILEEMOTION',     'Emoci�n');
define('_WCSMILESHOW',        'Acceso abreviado');
define('_WCSOUNDCMD',         'Intrucci�n');
define('_WCSOUNDFILE',        'Nombre del fichero');
define('_WCSOUNDTEXT',        'Chat Say Text');
define('_WCSOUNDSHOW',        'Mostrar acceso abreviado');
define('_WCYES',              'Si');
define('_WCNO',               'No');
define('_WCSAVESETTINGS',     'Guardar configuraci�n');
define('_WCSETTINGSSAVED',    'La configuraci�n se han guardado');
define('_WCSETTINGSERR',      'La configuraci�n no se ha podido guardar!');
define('_WCONLINE',           'conectado');
define('_WCALLOWCREATE',      'Permitir a los usuarios crear salas');
define('_WCONLYREGCANCREATE', 'Solo los usuarios registrados pueden crear salas');
define('_WCCREATEAROOM',      'Crea tu propia sala de chat');
define('_WCORIGINAL',         'Original');

// help
define('_WCHELPTITLE',        _WCAPPNAME.' Ayuda');
define('_WCHELPSMILETBL',     'Instalados los Smilies<br><br>La columna [codigo] muestra que hay que escribir para mostrar el smiley de la columna [Imagen].');
define('_WCHELPSOUNDTBL',     'Instalados los sonidos<br><br>La columna [instrucci�n] muestra que hay que escribir para escuchar el sonido.  La columna [Chat say text] muestra el texto que se ve.');
define('_WCHELPSOUNDTBLOPTS', '<b>Opciones:</b><br><b><i><username></i></b>  si un usuario envia un sonido, solo lo escucha el receptor.<br>p.e. <b><i>/hey judy</i></b> se enviara el sonido solo a Judy.');
define('_WCHELPTEXT1',        'Como usar los smilies en el texto');
define('_WCHELPTEXT2',        'Como insertar sonidos en el chat');
define('_WCHELPTEXT3',        'Otras instrucciones permitidas');
define('_WCHELPTOP',          'Ir arriba');
define('_WCHELPCLOSE',        'Cerrar ventana');
define('_WCHELPNODATA',       'No %s instalado en este momento');
define('_WCHELPCMDTBL',       'Intrucciones permitidas');
define('_WCHELPCMDDESC',      'Descripci�n');
define('_WCHELPCMDMSGHLP',    'Enviar un mensaje privado a <i>username</i>. Solo la vera el receptor.<br>Una forma r�pida de hacerlo es clicando sobre su nombre en la lista de usuarios de la derecha');

// install
define('_WCINSGENSETTINGS',   'Instalaci�n: Configuraci�n geneal para el WebChat');
define('_WCINSSAVESETTINGS',  'Guardar configuraci�n y continuar');
define('_WCINSCONFIGSAVED',   'Configuraci�n guardada y config.php creado correctamente.');
define('_WCINSTABLEERR',      'Error creando la tabla');
define('_WCINSTABLECREATED',  'tabla creada correctamente.');
define('_WCINSCONT',          'Continuar instalaci�n');
define('_WCINSDONE',          'Hecho');
define('_WCINSTALLED',        _WCAPPNAME.' se ha instalado correctamente!<br><br>Espero que te guste el '._WCAPPNAME.' y lo uses correctamente.  Por favor, envia bugs o peticiones a <a href="http://naturald.sytes.net">Natural Disasters</a>');
define('_WCINSADDINGDEF',     'Instalaci�n: A�adiendo algunos datos a las tablas...');
define('_WCINSDONETXT',       'Instalaci�n y Setup han concluido.  Clicando en [Done] se borrar� el fichero install.php y se completar� la instalaci�n.');
define('_WCINSCREATETABLES',  'Instalaci�n: Creanaod tablas...');
define('_WCINSADDINGSMILES',  'A�adiendo smiles...');
define('_WCINSADDINGROOMS',   'A�adiendo salas...');
define('_WCINSADDINGSOUNDS',  'A�adiendo sonidos...');
define('_WCINSADDINGERR',     'Error introduciendo datos en la tabla %s ');
define('_WCINSADDINGDONE',    'Datos a�adidos correctamente a la tabla %s ');

?>