<?
/*****************************************************************************************
 *  WebChat - multiple private/open room chat system for PostNuke                        *
 *****************************************************************************************
 *   David "Cyklone" Thompson   david@thompsonville.net                                  *
 *   portions credited to Daniel Toma [dt@dnt.ro] [http://www.webdev.ro]                 *
 *****************************************************************************************
 *  Read CHANGELOG for updates and bug fixes                                             *
 *****************************************************************************************
 * POST-NUKE Content Management System                                                   *
 * Copyright (C) 2001 by the Post-Nuke Development Team.                                 *
 * http://www.postnuke.com/                                                              *
 * --------------------------------------------------------------------------------------*
 * Based on:                                                                             *
 * PHP-NUKE Web Portal System - http://phpnuke.org/                                      *
 * Thatware - http://thatware.org/                                                       *
 *****************************************************************************************
 * CHANGELOG:                                                                            *
 * 08 Nov, 2001 - modified content display for grouping by room type with headings       *
 * [Cyklone]    - added 2 funcs to allow changing options thru the pn block admin        *
 *                interface                                                              *
 *****************************************************************************************
 * WebChatMaxiBlock Version  0.1                                                         *
 * for PHPNuke > 5.4 & PHPNukeWebChat                                                    *
 * 21. March 2002, Frank Wallacher, Saarport.NET (frank@saarport.net)                    *
 *****************************************************************************************/
if (eregi("block-WebChatMaxi.php",$PHP_SELF)) {
    Header("Location: index.php");
    die();
}
global $cookie, $prefix, $currentlang;
$modulename = "WebChat";
$basepath   = "modules/$modulename";

if(file_exists("$basepath/language/lang-".$currentlang.".php")) {
	include("$basepath/language/lang-".$currentlang.".php");
}
else {
	include("$basepath/language/lang-$language.php");
}

require "$basepath/inc/config.php";
$tstamp = time();
$tstamp -= $usertime;

$q=mysql_query("delete from ".$prefix."_chatuser where last < ".$tstamp);


  $content = "<table border=\"0\" cellspacing=\"3\">";
  $content .= "<tr valign=\"top\">";
  $content .= "<td><font class=\"pn-content\" align=\"left\"><b>Sala</b></td>";
  $content .= "<td><font class=\"pn-content\" align=\"right\"><b>Per.</b></td>";
  $sql = "select ".$prefix."_chatroom.*, count(".$prefix."_chatuser.rid) as users from ".$prefix."_chatroom left join ".$prefix."_chatuser on ".$prefix."_chatuser.rid = ".$prefix."_chatroom.rid group by ".$prefix."_chatroom.rid order by ".$prefix."_chatroom.typ, ".$prefix."_chatroom.name"; 
  $q = mysql_query($sql);
  if(mysql_num_rows($q) == 0){
    $content .= _WCNOACTIVE;
  } else {
    $roomtype = "P";
    while($result = mysql_fetch_array($q)) {
      if($row[refresh]) {
        if($roomtype != $result[typ])
          $top = true;
        else
          $top = false;
        if($top) 
          if($result[typ] == "N")
            $content .= "<tr valign=\"top\" align=\"left\"><td colspan=\"2\"><font class=\"pn-content\"><b>Normal Rooms</b></font></td></tr>";
          else
            $content .= "<tr valign=\"top\" align=\"left\"><td colspan=\"2\"><font class=\"pn-content\"><b>Private Rooms</b></font></td></tr>";
        $top = false;
      }
      $content .= "<tr valign=\"top\">";
      $content .= "<td><font class=\"pn-content\"><a href=\"modules.php?op=modload&name=".$modulename."&file=index&roomid=$result[rid]\">$result[name]</a></font></td>";
      $content .= "<td align=\"center\" valign=\"middle\">".$result[users].($result[users]==1?" ":"");
      if($row[url] && $result[users] != 0){
        $content .= "<br><i>";
        $first = true;
        $q2 = mysql_query("select name from ".$prefix."_chatuser where rid = ".$result[rid]);
        while($result2 = mysql_fetch_array($q2)){
          if($first) {
            $first = false;
            $content .= $result2[name];
          } else
            $content .= ", ".$result2[name];
        }
        $content .= "</i>";
      }
      $content .= "</td></tr>";
      $roomtype = $result[typ];
    }
  }
  $content .= "</table>";
  $row[content] = $content;
$content .= "<br><center>[ <a href=\"modules.php?op=modload&name=WebChat&file=index\">$modulename</a> ]</center>";


?>




