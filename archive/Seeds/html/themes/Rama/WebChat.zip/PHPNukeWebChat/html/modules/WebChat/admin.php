<?
/*****************************************************************************************
 *  WebChat - multiple private/open room chat system for PostNuke                        *
 *****************************************************************************************
 *   David "Cyklone" Thompson   david@thompsonville.net                                  *
 *   portions credited to Daniel Toma [dt@dnt.ro] [http://www.webdev.ro]                 *
 *****************************************************************************************
 *  Read CHANGELOG for updates and bug fixes                                             *
 *****************************************************************************************
 * POST-NUKE Content Management System                                                   *
 * Copyright (C) 2001 by the Post-Nuke Development Team.                                 *
 * http://www.postnuke.com/                                                              *
 * --------------------------------------------------------------------------------------*
 * Based on:                                                                             *
 * PHP-NUKE Web Portal System - http://phpnuke.org/                                      *
 * Thatware - http://thatware.org/                                                       *
 *****************************************************************************************/
 
if (!eregi('modules.php', $PHP_SELF)) 
  die ("You can't access this file directly...");

$ModName = basename( dirname( __FILE__ ) );
$basepath   = "modules/$ModName";
$imagepath  = "modules/$ModName/images";

$index = 0;

if(file_exists("modules/$ModName/language/lang-$lang.php"))
  include("modules/$ModName/language/lang-$lang.php");
else
  include("modules/$ModName/language/lang-english.php");

function disp_menu() {
  global $bgcolor1, $bgcolor2, $bgcolor4, $ModName;
  OpenTable();
?>
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0" WIDTH="100%" VALIGN="TOP" ALIGN="CENTER">
  <TR><TD BGCOLOR="<?=$bgcolor2?>">
  <TABLE BORDER="0" CELLPADDING="4" CELLSPACING="1" WIDTH="100%">
    <TR BGCOLOR="<?=$bgcolor2?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD ALIGN="LEFT" COLSPAN="2"><FONT CLASS="newstitle"><STRONG><?=_WCADMINMENU?></STRONG></FONT></TD>
    </TR>
    <TR BGCOLOR="<?=$bgcolor1?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD><FONT CLASS="pn-normal"><a href="modules.php?op=modload&name=<?=$ModName?>&file=admin&action=<?=_WCADMINGEN?>"><?=_WCADMINGEN?></FONT></TD>
      <TD><FONT CLASS="pn-normal"><?=_WCADMINGENDESC?></FONT></TD>
    </TR>
    <TR BGCOLOR="<?=$bgcolor1?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD><FONT CLASS="pn-normal"><a href="modules.php?op=modload&name=<?=$ModName?>&file=admin&action=<?=_WCADMINROOMS?>"><?=_WCADMINROOMS?></a></FONT></TD>
      <TD><FONT CLASS="pn-normal"><?=_WCADMINROOMSDESC?></FONT></TD>
    </TR>
    <TR BGCOLOR="<?=$bgcolor1?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD><FONT CLASS="pn-normal"><a href="modules.php?op=modload&name=<?=$ModName?>&file=admin&action=<?=_WCADMINSMILES?>"><?=_WCADMINSMILES?></a></FONT></TD>
      <TD><FONT CLASS="pn-normal"><?=_WCADMINSMILEDESC?></FONT></TD>
    </TR>
    <TR BGCOLOR="<?=$bgcolor1?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD><FONT CLASS="pn-normal"><a href="modules.php?op=modload&name=<?=$ModName?>&file=admin&action=<?=_WCADMINSOUNDS?>"><?=_WCADMINSOUNDS?></a></FONT></TD>
      <TD><FONT CLASS="pn-normal"><?=_WCADMINSOUNDDESC?></FONT></TD>
    </TR>
    <TR BGCOLOR="<?=$bgcolor1?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD><FONT CLASS="pn-normal"><a href="modules.php?op=modload&name=<?=$ModName?>&file=admin&action=<?=_WCADMINSPECIAL?>"><?=_WCADMINSPECIAL?></a></FONT></TD>
      <TD><FONT CLASS="pn-normal"><?=_WCADMINSPECIALDESC?></FONT></TD>
    </TR>
  </TABLE>
  </TD></TR>
</TABLE>
<?  
  CloseTable();    
}

function settings_menu() {
  global $ModName, $bgcolor1, $bgcolor2, $bgcolor3, $prefix, $dbhost,
         $dbname, $dbuname, $dbprefix, $dbpass;
  require "modules/$ModName/inc/config.php";
  if($dbhost == '') {
    global $pnconfig;
    $dbhost  = $pnconfig[dbhost];
    $dbuname = $pnconfig[dbuname];
    $dbpass  = $pnconfig[dbpass];
    $dbname  = $pnconfig[dbname];
  }  
  OpenTable();
?>
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0" WIDTH="100%" VALIGN="TOP">
  <TR><TD BGCOLOR="<?=$bgcolor2?>">
  <TABLE BORDER="0" CELLPADDING="4" CELLSPACING="1" WIDTH="100%">
    <TR BGCOLOR="<?=$bgcolor2?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD COLSPAN="6"><FONT CLASS="newstitle"><a href="modules.php?op=modload&name=<?=$ModName?>&file=admin"><?=_WCADMINMENU?></a>&nbsp;��&nbsp;<STRONG><?=_WCADMINGEN?></STRONG></FONT></TD>
    </TR>
    <TR BGCOLOR="<?=$bgcolor3?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD COLSPAN="6"><FONT CLASS="newstitle"><?=_WCADMINGENMSG1?></FONT></TD>
    </TR>
    <form action="modules.php" method="post">
    <input type="hidden" name="name" value="<?=$ModName?>">
    <input type="hidden" name="file" value="admin">
    <input type="hidden" name="op" value="modload">
    <input type="hidden" name="action" value="SAVESETTINGS">
<?
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINDBHOST."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xdbhost\" size=20 value=\"$dbhost\" readonly></TD></TR>";
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINDBUNAME."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xdbuname\" size=20 value=\"$dbuname\" readonly></TD></TR>";
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINDBPW."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xdbpass\" size=20 value=\"$dbpass\" readonly></TD></TR>";
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINDBNAME."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xdbname\" size=20 value=\"$dbname\" readonly></TD></TR>";
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINDBPREFIX."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xprefix\" size=20 value=\"$prefix\" readonly></TD></TR>";
?>
    <TR BGCOLOR="<?=$bgcolor3?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD COLSPAN="6"><FONT CLASS="newstitle"><?=_WCADMINGENMSG2?></FONT></TD>
    </TR>
<?
  $set_allowcreate[$allowcreate] = 'checked';
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCALLOWCREATE."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"radio\" name=\"xallowcreate\" value=\"1\" $set_allowcreate[1]>"._WCYES."&nbsp;<INPUT TYPE=\"radio\" name=\"xallowcreate\" value=\"0\" $set_allowcreate[0]>"._WCNO."</TD></TR>";
  $set_onlyregcancreate[$onlyregcancreate] = 'checked';
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCONLYREGCANCREATE."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"radio\" name=\"xonlyregcancreate\" value=\"1\" $set_onlyregcancreate[1]>"._WCYES."&nbsp;<INPUT TYPE=\"radio\" name=\"xonlyregcancreate\" value=\"0\" $set_onlyregcancreate[0]>"._WCNO."</TD></TR>";
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINMSGREFRESH."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xmsg_refresh\" size=\"10\" value=\"$msg_refresh\"></TD></TR>";
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINUSRTIME."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xusertime\" size=\"10\" value=\"$usertime\"></TD></TR>";
  $set_showsmiles[$showsmiles] = 'checked';
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINSHOWSMILES."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"radio\" name=\"xshowsmiles\" value=\"1\" $set_showsmiles[1]>"._WCYES."&nbsp;<INPUT TYPE=\"radio\" name=\"xshowsmiles\" value=\"0\" $set_showsmiles[0]>"._WCNO."</TD></TR>";
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINSMILESDIR."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xsmilesdir\" size=\"20\" value=\"$smilesdir\"></TD></TR>";
  $set_usesounds[$usesounds] = 'checked';
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINUSESOUNDS."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"radio\" name=\"xusesounds\" value=\"1\" $set_usesounds[1]>"._WCYES."&nbsp;<INPUT TYPE=\"radio\" name=\"xusesounds\" value=\"0\" $set_usesounds[0]>"._WCNO."</TD></TR>";
  $set_showsounds[$showsounds] = 'checked';
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINSHOWSOUNDS."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"radio\" name=\"xshowsounds\" value=\"1\" $set_showsounds[1]>"._WCYES."&nbsp;<INPUT TYPE=\"radio\" name=\"xshowsounds\" value=\"0\" $set_showsounds[0]>"._WCNO."</TD></TR>";
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINSNDSDIR."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"TEXT\" name=\"xsoundsdir\" size=\"20\" value=\"$soundsdir\"></TD></TR>";
  $set_showusers[$showusers] = 'checked';
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINSHOWUSRS."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"radio\" name=\"xshowusers\" value=\"1\" $set_showusers[1]>"._WCYES."&nbsp;<INPUT TYPE=\"radio\" name=\"xshowusers\" value=\"0\" $set_showusers[0]>"._WCNO."</TD></TR>";
  $set_keeponline[$keeponline] = 'checked';
  print "<TR BGCOLOR=\"$bgcolor1\" ALIGN=\"LEFT\" VALIGN=\"MIDDLE\"><TD WIDTH=\"30%\"><FONT CLASS=\"pn-normal\">"._WCADMINKEEPONLINE."</TD>";
  print "<TD><FONT CLASS=\"pn-normal\"><INPUT TYPE=\"radio\" name=\"xkeeponline\" value=\"1\" $set_keeponline[1]>"._WCYES."&nbsp;<INPUT TYPE=\"radio\" name=\"xkeeponline\" value=\"0\" $set_keeponline[0]>"._WCNO."</TD></TR>";
?>
  </TABLE>
  </TD></TR>
</TABLE>
<?
  CloseTable();
  print "<br><center><input type=\"submit\" value=\""._WCSAVESETTINGS."\"></center></form>";
  CloseTable();
include 'footer.php';
}

function save_settings($vars) {
global $ModName;

	if(!$fp = fopen("modules/$ModName/inc/config.php",'w')) {
	  $errormsg = _WCSETTINGSERR;
    return $errormsg;
	}
  $config_header[] = "<?\n";
  $config_header[] = "/****************************************************************************************\n";
  $config_header[] = " * WebChat config file                                                                  *\n";
  $config_header[] = " *   This file is edited thru the WebChat Administration, DO NOT EDIT HERE!!            *\n";
  $config_header[] = " *   If edited here, it may not correctly read when editing thru the admin interface.   *\n";
  $config_header[] = " ****************************************************************************************/\n";
  $config_vars = array(
    'dbhost'            => $vars[xdbhost],
    'dbuname'           => $vars[xdbuname],
    'dbpass'            => $vars[xdbpass],
    'dbname'            => $vars[xdbname],
    'prefix'            => $vars[xprefix],
    'allowcreate'       => $vars[xallowcreate],
    'onlyregcancreate'  => $vars[xonlyregcancreate],
    'msg_refresh'       => $vars[xmsg_refresh],
    'usertime'          => $vars[xusertime],
    'showsmiles'        => $vars[xshowsmiles],
    'smilesdir'         => $vars[xsmilesdir],
    'usesounds'         => $vars[xusesounds],
    'showsounds'        => $vars[xshowsounds],
    'soundsdir'         => $vars[xsoundsdir],
    'showusers'         => $vars[xshowusers],
    'keeponline'        => $vars[xkeeponline]);
    
	if(phpversion() >= '4.0.0') { // php4+
		foreach($config_vars as $k=>$v) {
			$config_header[] = "\$$k = '$v';\n";
		}
	}
	else { // php3
		while(list($k, $v) = each($config_vars)) {
			$config_header[] = "\$$k = '$v';\n";
		}
	}
	
	$config_header[] = '?>';

	fwrite($fp, implode($config_header,''));
	fclose($fp);
	$errormsg = _WCSETTINGSSAVED;
  return $errormsg;
}

function chatroom_menu() {
  global $ModName, $bgcolor1, $bgcolor2, $bgcolor3, $prefix;
  OpenTable();
?>
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0" WIDTH="100%" VALIGN="TOP">
  <TR><TD BGCOLOR="<?=$bgcolor2?>">
  <TABLE BORDER="0" CELLPADDING="4" CELLSPACING="1" WIDTH="100%">
    <TR BGCOLOR="<?=$bgcolor2?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD COLSPAN="7"><FONT CLASS="newstitle"><a href="modules.php?op=modload&name=<?=$ModName?>&file=admin"><?=_WCADMINMENU?></a>&nbsp;��&nbsp;<STRONG><?=_WCADMINROOMS?></STRONG></FONT></TD>
    </TR>
    <TR BGCOLOR="<?=$bgcolor3?>" VALIGN="MIDDLE">
      <TD ALIGN="LEFT"><FONT CLASS="pn-normal"><STRONG><?=_WCROOMNAME?></STRONG></FONT></TD>
      <TD ALIGN="CENTER"><FONT CLASS="pn-normal"><STRONG><?=_WCROOMOCCUPANTS?></STRONG></FONT></TD>
      <TD ALIGN="LEFT"><FONT CLASS="pn-normal"><STRONG><?=_WCROOMDESC?></STRONG></FONT></TD>
      <TD ALIGN="CENTER"><FONT CLASS="pn-normal"><STRONG><?=_WCROOMTYPE?></STRONG></FONT></TD>
      <TD ALIGN="LEFT"><FONT CLASS="pn-normal"><STRONG><?=_WCPASSWORD?></STRONG></FONT></TD>
      <TD ALIGN="CENTER"><FONT CLASS="pn-normal"><STRONG><?=_WCORIGINAL?></STRONG></FONT></TD>
      <TD ALIGN="CENTER"><FONT CLASS="pn-normal"><STRONG><?=_WCACTION?></STRONG></FONT></TD>
    </TR>
<?
  $sql = "select ".$prefix."_chatroom.*, count(".$prefix."_chatuser.rid) as users from ".$prefix."_chatroom left join ".$prefix."_chatuser on ".$prefix."_chatuser.rid = ".$prefix."_chatroom.rid group by ".$prefix."_chatroom.rid order by ".$prefix."_chatroom.rid";
  $q=mysql_query($sql);
  while ($row = mysql_fetch_array($q)) {
?>
    <form name="frm_<?=$row[rid]?>" action="modules.php" method="post">
    <input type="hidden" name="name" value="<?=$ModName?>">
    <input type="hidden" name="file" value="admin">
    <input type="hidden" name="op" value="modload">
    <input type="hidden" name="action" value="EDITROOM">
    
    <tr bgcolor="<?=$bgcolor1?>">
      <td align="left">
        <input type=hidden name="rid" value="<?=$row[rid]?>">
        <input name="rname" value="<?=$row[name]?>" size="15">
      </td>
      <td align="center">
        <font class=pn-normal><?=$row[users]." "._WCONLINE?></font>
      </td>
      <td align="left">
        <input name="descript" value="<?=$row[descript]?>" size="30">
      </td>
      <td align="center">
        <select name="typ">
          <option value="N" <? if($row[typ]=='N') echo 'selected'; ?>><?=_WCNORMROOM?></option>
          <option value="P" <? if($row[typ]=='P') echo 'selected'; ?>><?=_WCPRIVROOM?></option>
        </select>
      </td>
      <td align="left">
        <? if($row[typ] == 'P') echo "<input name=\"pass\" value=\"$row[pass]\" size=\"10\">"; else echo "&nbsp;"; ?>
      </td>
      <td align="center">
        <font class=pn-normal><?=($row[orig] == 1 ? _WCYES : _WCNO)?></font>
      </td>
      <td align="center">
        <input type="submit" name="subaction" value="<?=_WCMODIFY?>">
        <input type="submit" name="subaction" value="<?=_WCDELETE?>">
      </td>
    </tr>
    </form>
<?
  }  // bottom of while
?>
    <form action="modules.php" method="post">
    <input type="hidden" name="name" value="<?=$ModName?>">
    <input type="hidden" name="file" value="admin">
    <input type="hidden" name="op" value="modload">
    <input type="hidden" name="action" value="ADDROOM">

    <tr bgcolor="<?=$bgcolor1?>">
      <td align="left">
        <input name="rname" value="" size="15">
      </td>
      <td align="left">
        &nbsp;
      </td>
      <td align="left">
        <input name="descript" value="" size="30">
      </td>
      <td align="left">
        <select name="typ">
          <option value="N"><?=_WCNORMROOM?></option>
          <option value="P"><?=_WCPRIVROOM?></option>
        </select>
      </td>
      <td align="left">
        <input name="pass" value="" size="10">
      </td>
      <td align="center">
        &nbsp;
      </td>
      <td align="center">
        <input type="submit" name="submit" value="<?=_WCADD?>">
      </td>
    </tr>
    </form>
  </TABLE>
  </TD></TR>
</TABLE>
<?
  CloseTable();
  CloseTable();
  include 'footer.php';
}

function smiles_menu() {
  global $ModName, $bgcolor1, $bgcolor2, $bgcolor3, $prefix;
  require "modules/$ModName/inc/config.php";
  OpenTable();
?>
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0" WIDTH="100%" VALIGN="TOP">
  <TR><TD BGCOLOR="<?=$bgcolor2?>">
  <TABLE BORDER="0" CELLPADDING="4" CELLSPACING="1" WIDTH="100%">
    <TR BGCOLOR="<?=$bgcolor2?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD COLSPAN="6"><FONT CLASS="newstitle"><a href="modules.php?op=modload&name=<?=$ModName?>&file=admin"><?=_WCADMINMENU?></a>&nbsp;��&nbsp;<STRONG><?=_WCADMINSMILES?></STRONG></FONT></TD>
    </TR>
    <TR BGCOLOR="<?=$bgcolor3?>" VALIGN="MIDDLE">
      <TD ALIGN="LEFT" COLSPAN="6"><FONT CLASS="pn-normal"><STRONG><?=_WCADMINCURSMILEDIR?>:</STRONG>&nbsp;&nbsp;modules/<?=$ModName."/".$smilesdir?></TD>
    </TR>
    <TR BGCOLOR="<?=$bgcolor3?>" VALIGN="MIDDLE">
      <TD ALIGN="CENTER"><FONT CLASS="pn-normal"><STRONG><?=_WCSMILEIMAGE?></STRONG></FONT></TD>
      <TD ALIGN="LEFT"><FONT CLASS="pn-normal"><STRONG><?=_WCSMILECODE?></STRONG></FONT></TD>
      <TD ALIGN="LEFT"><FONT CLASS="pn-normal"><STRONG><?=_WCSMILEFILE?></STRONG></FONT></TD>
      <TD ALIGN="LEFT"><FONT CLASS="pn-normal"><STRONG><?=_WCSMILEEMOTION?></STRONG></FONT></TD>
      <TD ALIGN="CENTER"><FONT CLASS="pn-normal"><STRONG><?=_WCSMILESHOW?></STRONG></FONT></TD>
      <TD ALIGN="CENTER"><FONT CLASS="pn-normal"><STRONG><?=_WCACTION?></STRONG></FONT></TD>
    </TR>
<?
  $q = mysql_query("select * from ".$prefix."_chatsmile order by sid");
  while($row = mysql_fetch_array($q)) {
?>
    <form name="frm_<?=$row[sid]?>" action="modules.php" method="post">
    <input type="hidden" name="name" value="<?=$ModName?>">
    <input type="hidden" name="file" value="admin">
    <input type="hidden" name="op" value="modload">
    <input type="hidden" name="action" value="EDITSMILE">
    
    <tr bgcolor="<?=$bgcolor1?>">
      <td align="center">
        <input type=hidden name="sid" value="<?=$row[sid]?>">
        <img src="modules/<?=$ModName?>/<?=$smilesdir?>/<?=$row[file]?>" border="0" alt="<?=$row[code]?>">
      </td>
      <td align="left">
        <input name="scode" value="<?=$row[code]?>" size="10">
      </td>
      <td align="left">
        <input name="sfile" value="<?=$row[file]?>" size="15">
      </td>
      <td align="left">
        <input name="semotion" value="<?=$row[emotion]?>" size="20">
      </td>
      <td align="center">
        <select name="sshowit">
          <option value="0" <? if($row[showit]=='0') echo 'selected'; ?>><?=_WCNO?></option>
          <option value="1" <? if($row[showit]=='1') echo 'selected'; ?>><?=_WCYES?></option>
        </select>
      </td>
      <td align="center">
        <input type="submit" name="subaction" value="<?=_WCMODIFY?>">
        <input type="submit" name="subaction" value="<?=_WCDELETE?>">
      </td>
    </tr>
    </form>
<?
  } // bottom of while
?>
    <form action="modules.php" method="post">
    <input type="hidden" name="name" value="<?=$ModName?>">
    <input type="hidden" name="file" value="admin">
    <input type="hidden" name="op" value="modload">
    <input type="hidden" name="action" value="ADDSMILE">

    <tr bgcolor="<?=$bgcolor1?>">
      <td align="left">
        &nbsp;
      </td>
      <td align="left">
        <input name="scode" value="" size="10">
      </td>
      <td align="left">
        <input name="sfile" value="" size="15">
      </td>
      <td align="left">
        <input name="semotion" value="" size="20">
      </td>
      <td align="center">
        <select name="sshowit">
          <option value="0"><?=_WCNO?></option>
          <option value="1"><?=_WCYES?></option>
        </select>
      </td>
      <td align="center">
        <input type="submit" name="submit" value="<?=_WCADD?>">
      </td>
    </tr>
    </form>
  </TABLE>
  </TD></TR>
</TABLE>

<?  
  CloseTable();
  CloseTable();
  include 'footer.php';
}

function sounds_menu() {
  global $ModName, $bgcolor1, $bgcolor2, $bgcolor3, $prefix;
  require "modules/$ModName/inc/config.php";
  OpenTable();
?>
<TABLE BORDER="0" CELLPADDING="1" CELLSPACING="0" WIDTH="100%" VALIGN="TOP">
  <TR><TD BGCOLOR="<?=$bgcolor2?>">
  <TABLE BORDER="0" CELLPADDING="4" CELLSPACING="1" WIDTH="100%">
    <TR BGCOLOR="<?=$bgcolor2?>" ALIGN="LEFT" VALIGN="MIDDLE">
      <TD COLSPAN="6"><FONT CLASS="newstitle"><a href="modules.php?op=modload&name=<?=$ModName?>&file=admin"><?=_WCADMINMENU?></a>&nbsp;��&nbsp;<STRONG><?=_WCADMINSOUNDS?></STRONG></FONT></TD>
    </TR>
    <TR BGCOLOR="<?=$bgcolor3?>" VALIGN="MIDDLE">
      <TD ALIGN="LEFT" COLSPAN="4"><FONT CLASS="pn-normal"><STRONG><?=_WCADMINCURSOUNDDIR?>:</STRONG>&nbsp;&nbsp;modules/<?=$ModName."/".$soundsdir?></TD>
    </TR>
    <TR BGCOLOR="<?=$bgcolor3?>" VALIGN="MIDDLE">
      <TD ALIGN="LEFT"><FONT CLASS="pn-normal"><STRONG><?=_WCSOUNDCMD?></STRONG></FONT></TD>
      <TD ALIGN="LEFT"><FONT CLASS="pn-normal"><STRONG><?=_WCSOUNDFILE?></STRONG></FONT></TD>
      <TD ALIGN="LEFT"><FONT CLASS="pn-normal"><STRONG><?=_WCSOUNDTEXT?></STRONG></FONT></TD>
      <TD ALIGN="CENTER"><FONT CLASS="pn-normal"><STRONG><?=_WCACTION?></STRONG></FONT></TD>
    </TR>
<?
  $q = mysql_query("select * from ".$prefix."_chatsound order by sid");
  while($row = mysql_fetch_array($q)) {
?>
    <form name="frm_<?=$row[sid]?>" action="modules.php" method="post">
    <input type="hidden" name="name" value="<?=$ModName?>">
    <input type="hidden" name="file" value="admin">
    <input type="hidden" name="op" value="modload">
    <input type="hidden" name="action" value="EDITSOUND">
    
    <tr bgcolor="<?=$bgcolor1?>">
      <td align="left">
        <input type=hidden name="sid" value="<?=$row[sid]?>">
        <input name="scmd" value="<?=$row[cmd]?>" size="15">
      </td>
      <td align="left">
        <input name="sfile" value="<?=$row[file]?>" size="15">
      </td>
      <td align="left">
        <input name="ssaytext" value="<?=$row[saytext]?>" size="30">
      </td>
      <td align="center">
        <input type="submit" name="subaction" value="<?=_WCMODIFY?>">
        <input type="submit" name="subaction" value="<?=_WCDELETE?>">
      </td>
    </tr>
    </form>
<?
  } // bottom of while
?>
    <form action="modules.php" method="post">
    <input type="hidden" name="name" value="<?=$ModName?>">
    <input type="hidden" name="file" value="admin">
    <input type="hidden" name="op" value="modload">
    <input type="hidden" name="action" value="ADDSOUND">

    <tr bgcolor="<?=$bgcolor1?>">
      <td align="left">
        <input name="scmd" value="" size="15">
      </td>
      <td align="left">
        <input name="sfile" value="" size="15">
      </td>
      <td align="left">
        <input name="ssaytext" value="" size="30">
      </td>
      <td align="center">
        <input type="submit" name="submit" value="<?=_WCADD?>">
      </td>
    </tr>
    </form>
  </TABLE>
  </TD></TR>
</TABLE>

<?  
  CloseTable();
  CloseTable();
  include 'footer.php';
}

/********************** main **************************************/
include 'header.php';
OpenTable();
include "modules/$ModName/wc_header.php";

if(!is_admin($admin)) {
 echo "Sorry, you are not an administrator!";
} else {
  if(isset($action)){
    unset($errormsg);
    switch($action) {
      case "EDITROOM":
        if($subaction == _WCMODIFY)
          $q = mysql_query("update ".$prefix."_chatroom set name='$rname', descript='$descript', typ='$typ', pass='$pass' where rid=$rid");
        elseif($subaction == _WCDELETE) {
          $q = mysql_query("select count(uid) as total_u from ".$prefix."_chatuser where rid=$rid");
          $r = mysql_fetch_array($q);
          if ($r[total_u] == 0) 
            $q = mysql_query("delete from ".$prefix."_chatroom where rid=$rid");
          else {
            $errormsg = _WCNOTEMPTY;
            break;
          }
        }
        chatroom_menu();
        exit;
      case "ADDROOM":
        $q = mysql_query("insert into ".$prefix."_chatroom values (null, '$rname', '$descript', '$typ', '$pass', '1')");
        chatroom_menu();
        exit;
      case _WCADMINROOMS:
        chatroom_menu();
        exit;
      case _WCADMINGEN:
        settings_menu();
        exit;
      case "EDITSMILE":
        if($subaction == _WCMODIFY) 
          $q = mysql_query("update ".$prefix."_chatsmile set code='$scode', file='$sfile', emotion='$semotion', showit='$sshowit' where sid=$sid");
        elseif($subaction == _WCDELETE)
          $q = mysql_query("delete from ".$prefix."_chatsmile where sid=$sid");
        smiles_menu();
        exit;
      case "ADDSMILE":
        $q = mysql_query("insert into ".$prefix."_chatsmile values (null, '$scode', '$sfile', '$semotion', '$sshowit')");
        smiles_menu();
        exit;
      case _WCADMINSMILES:
        smiles_menu();
        exit;
      case "EDITSOUND":
        if($subaction == _WCMODIFY) {
          $q = mysql_query("update ".$prefix."_chatsound set cmd='$scmd', file='$sfile', saytext='$ssaytext' where sid=$sid");
        }
        elseif($subaction == _WCDELETE)
          $q = mysql_query("delete from ".$prefix."_chatsound where sid=$sid");
        sounds_menu();
        exit;
      case "ADDSOUND":
        $q = mysql_query("insert into ".$prefix."_chatsound values (null, '$scmd', '$sfile', '$ssaytext')");
        sounds_menu();
        exit;
      case _WCADMINSOUNDS:
        sounds_menu();
        exit;
      
      case "SAVESETTINGS":
        $errormsg = save_settings($GLOBALS[HTTP_POST_VARS]);
    }
    disp_menu();
    if(isset($errormsg))
      echo "<BR><STRONG>$errormsg</STRONG>";
  } else {
    // default, just display menu
    disp_menu();
  }
}
CloseTable();
include "modules/$ModName/wc_footer.php";
include 'footer.php';
?>
