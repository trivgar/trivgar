<?

/************************************************************************/
/* PHP-NUKE: Web Portal System                                          */
/* ===========================                                          */
/*                                                                      */
/* Copyright (c) 2002 by Francisco Burzi (fbc@mandrakesoft.com)         */
/* http://phpnuke.org                                                   */
/*======================================================================*/
/*                MiniSideBlock for PHPWebChat v1-0.6                   */ 
/*               Copyright (c) 2002 by Frank Wallacher                  */
/*         (webmaster@saarport.net) http://www.saarport.net             */
/*       Shows the absulute number of chatters in your WebChat          */
/*======================================================================*/
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/

if (eregi("block-WebChat.php", $PHP_SELF)) {
    Header("Location: index.php");
    die();
}

  global $cookie, $prefix, $currentlang;
  
  $showusers = true;
  $modulename = "WebChat";
  
  $basepath   = "modules/$modulename";
  
  if(file_exists("$basepath/language/block-".$currentlang.".php")) {
	include("$basepath/language/block-".$currentlang.".php");
  }
  else {
	include("$basepath/language/block-$language.php");
  }

  
  require "$basepath/inc/config.php";
  
  # some cleaning
  $tstamp = time();
  $tstamp -= $usertime;
  $q=mysql_query("delete from ".$prefix."_chatuser where last < ".$tstamp);


  $result = mysql_query("select * FROM $prefix"._chatuser." WHERE uid >='1' order by uid");
  $nummembers = mysql_num_rows($result);
  
  $content = "<center><table width=100% border=0>";
  $content .= "<tr><td>"._PRE."</td></tr>";
  $content .= "<tr><td>$nummembers "._CHATTER.".</td></tr>"; 
  $content .= "<tr><td</td></tr>"; 
  $content .= "<tr><td><a href=\"modules.php?op=modload&name=WebChat\">"._LETSCHAT."</a></td></tr>"; 

  $content .= "</table>";
       
?>