<?
/*****************************************************************************************
 *  WebChat - multiple private/open room chat system for PostNuke                        *
 *****************************************************************************************
 *   David "Cyklone" Thompson   david@thompsonville.net                                  *
 *   portions credited to Daniel Toma [dt@dnt.ro] [http://www.webdev.ro]                 *
 *****************************************************************************************
 *  Read CHANGELOG for updates and bug fixes                                             *
 *****************************************************************************************
 * POST-NUKE Content Management System                                                   *
 * Copyright (C) 2001 by the Post-Nuke Development Team.                                 *
 * http://www.postnuke.com/                                                              *
 * --------------------------------------------------------------------------------------*
 * Based on:                                                                             *
 * PHP-NUKE Web Portal System - http://phpnuke.org/                                      *
 * Thatware - http://thatware.org/                                                       *
 *****************************************************************************************/
?>
<html>
<head>
<title>In</title>
<style>
<!--
INPUT {
  border : #5566BB;	
  border-style : solid;	
  border-width : thin; 
  background-color: #FEFCD0; 
  color : #000000;	
  font : normal;
  font-size: 10pt;
}
-->
</style>
<script>
function doSubmit() {
  if (document.all) {
    top.wSend.document.all['form2'].txt.value=escape(document.all['form1'].txt.value);
    top.wSend.document.all['form2'].submit();
    document.all['form1'].txt.value='';
  } else {
    top.wSend.document.form2.txt.value=escape(document.form1.txt.value);
    top.wSend.document.form2.submit();
    document.form1.txt.value='';
  }
  setFocus();
  return false;
}

function doQuit() {
  top.location="quit.php?rid=<?=$rid ?>&uid=<?=$uid ?>&reason=0&lang=<?=$lang ?>";
}

function doHelpPopup() {
  var HelpWin = window.open("<?='help.php?lang='.$lang ?>","openScript","width=300,height=450,resizable=no,scrollbars=yes,toolbar=no,location=no,directories=no,status=no");
}

function setFocus() {
  if (document.all) {
    document.all['form1'].txt.focus(); 
  } else {
    document.form1.txt.focus();
  }
}

function setsmiley(what){
	document.form1.txt.value = document.form1.elements.txt.value+" "+what+" ";
	document.form1.txt.focus();
}

</script>
</head>
<body bgcolor="#EEEEFF" marginwidth="0" marginheight="0" leftmargin="3" topmargin="3" onLoad="setFocus()">
<table border="0" width="100%" cellpadding="0" cellspacing="0">
<form action="#" name="form1" method="get" autocomplete="off" onSubmit="return doSubmit();">
  <tr>
    <td align="left">
      <input type="text" size="60" name="txt" maxlength="255">
    </td>
    <td align="right">
      <a href="javascript:void(doSubmit())" onMouseover="document.images['send'].src='images/send2.gif'" onMouseout ="document.images['send'].src='images/send1.gif'">
      <img src="images/send1.gif" name="send" border=0 align="top"></a>
      <a href="javascript:void(doHelpPopup())" onMouseover="document.images['help'].src='images/help2.gif'" onMouseout ="document.images['help'].src='images/help1.gif'">
      <img src="images/help1.gif" name="help" border=0 align="top"></a>
    </td>
  </tr>
  <tr>
<?
  require("./inc/config.php");
  
  if(file_exists("language/lang-$lang.php"))
    include("language/lang-$lang.php");
  else
    include("language/lang-english.php");
  
  if($showsmiles == "1") {
    require("./inc/mysql.lib.php");
    echo "<td align=\"left\">";
    $DbLink = new DB($dbhost, $dbname, $dbuname, $dbpass);            
    $DbLink->query("SELECT code, file, emotion, showit as length FROM ".$prefix."_chatsmile ORDER BY length DESC");
    if($DbLink->num_rows() > 0) {
      while(list($code, $filename, $emotion, $showit) = $DbLink->next_record()) {
        if($showit == "1")
          echo "<a href=\"javascript:setsmiley('".$code."')\"><img src=\"".$smilesdir."/".$filename."\" border=\"0\" alt=\"".$emotion."\"></a>&nbsp;";
      }
    }
    $DbLink->clean_results();
    $DbLink->close();
    echo "</td>";
  } else {
    echo "<td align=\"left\"><font size=\"-2\" face=\"MS Sans Serif\">"._WCCHATTIPS."</td>";
  }
?>
    <td align="right">
      <a href="javascript:void(doQuit())" onMouseover="document.images['quit'].src='images/quit2.gif'" onMouseout ="document.images['quit'].src='images/quit1.gif'">
      <img src="images/quit1.gif" name="quit" border=0 align="bottom"></a>
    </td>
  </tr>
<?
  if($showsmiles == "1") {
    echo "<tr><td align=\"left\"><font size=\"-2\" face=\"MS Sans Serif\">"._WCCHATTIPS."</td></tr>";
  }  
?>
</form>
</table>
</body>
</html>
