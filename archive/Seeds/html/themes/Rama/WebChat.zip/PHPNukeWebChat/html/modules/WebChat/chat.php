<?
/*****************************************************************************************
 *  WebChat - multiple private/open room chat system for PostNuke                        *
 *****************************************************************************************
 *   David "Cyklone" Thompson   david@thompsonville.net                                  *
 *   portions credited to Daniel Toma [dt@dnt.ro] [http://www.webdev.ro]                 *
 *****************************************************************************************
 *  Read CHANGELOG for updates and bug fixes                                             *
 *****************************************************************************************
 * POST-NUKE Content Management System                                                   *
 * Copyright (C) 2001 by the Post-Nuke Development Team.                                 *
 * http://www.postnuke.com/                                                              *
 * --------------------------------------------------------------------------------------*
 * Based on:                                                                             *
 * PHP-NUKE Web Portal System - http://phpnuke.org/                                      *
 * Thatware - http://thatware.org/                                                       *
 *****************************************************************************************/

  require("./inc/config.php");
  if($showsmiles == "1")
    $input_ht = 70;
  else
    $input_ht = 50;
  $chatroom = stripslashes($chatroom);
?>
<html>
<link rel="stylesheet" href="main.css">
<head>
<title>WebChat [<?=$chatroom ?>]</title>
</head>
<frameset cols="*,100" frameborder="NO" border="0" framespacing="0" rows="*"> 
  <frameset rows="*,<?=$input_ht?>" frameborder="NO" border="0" framespacing="0"> 
    <frameset rows="21,*" frameborder="NO" border="0" framespacing="0" cols="*"> 
      <frame name="wSend" scrolling="NO" noresize src="send.php?rid=<?=$rid ?>&uid=<?=$uid ?>&tz=<?=$tz ?>&chatroom=<?=$chatroom ?>&lang=<?=$lang ?>" >
      <frame name="wOut" scrolling="AUTO" src="out.php">
    </frameset>
    <frame name="wIn" scrolling="NO" noresize src="in.php?rid=<?=$rid ?>&uid=<?=$uid ?>&lang=<?=$lang ?>">
  </frameset>
  <frameset rows="*,20,<?=$input_ht?>" frameborder="NO" border="0" framespacing="0"> 
    <frame name="wUsers" scrolling="NO" noresize src="users.php?rid=<?=$rid ?>&uid=<?=$uid ?>&username=<?=$username ?>">
    <frame name="wReceive" scrolling="NO" noresize src="receive.php?rid=<?=$rid ?>&uid=<?=$uid ?>&username=<?=$username ?>&tz=<?=$tz ?>&first=1&allowsounds=1&lang=<?=$lang ?>">
    <frame name="wLogo" scrolling="NO" noresize src="logo.php">
  </frameset>
</frameset>
<noframes><body bgcolor="#FFFFFF" text="#000000">
<b>Lo siento, tu navegador no soporta nuestro WebChat</b>
</body></noframes>
