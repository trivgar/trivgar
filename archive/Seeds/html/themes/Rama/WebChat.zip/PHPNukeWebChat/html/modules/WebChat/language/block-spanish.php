<?
/*****************************************************************************************
 *  WebChat Sideblock for PHPNuke                                                        *
 *****************************************************************************************
 * Based on:                                                                             *
 * PHP-NUKE Web Portal System - http://phpnuke.org/                                      *
 * Thatware - http://thatware.org/                                                       *
 *****************************************************************************************/

// Main
//Para el bloque MiniChat
define('_TITLE',          'WebChat');
define('_PRE',            'Usuarios en las salas:');
define('_CHATTER',     'Usuarios');
define('_LETSCHAT',    'Entrar Chat');
?>