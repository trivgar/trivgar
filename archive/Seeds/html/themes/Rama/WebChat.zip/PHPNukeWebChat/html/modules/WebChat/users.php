<?php
/*****************************************************************************************
 *  WebChat - multiple private/open room chat system for PostNuke                        *
 *****************************************************************************************
 *   David "Cyklone" Thompson   david@thompsonville.net                                  *
 *   portions credited to Daniel Toma [dt@dnt.ro] [http://www.webdev.ro]                 *
 *****************************************************************************************
 *  Read CHANGELOG for updates and bug fixes                                             *
 *****************************************************************************************
 * POST-NUKE Content Management System                                                   *
 * Copyright (C) 2001 by the Post-Nuke Development Team.                                 *
 * http://www.postnuke.com/                                                              *
 * --------------------------------------------------------------------------------------*
 * Based on:                                                                             *
 * PHP-NUKE Web Portal System - http://phpnuke.org/                                      *
 * Thatware - http://thatware.org/                                                       *
 *****************************************************************************************/

$modulename = basename( dirname( __FILE__ ) );

require("./inc/config.php"); 
require("./inc/mysql.lib.php");

$DbLink = new DB($dbhost, $dbname, $dbuname, $dbpass);

?>
<html>
<head>
<title>Users</title>
<link rel="stylesheet" href="main.css">
<SCRIPT LANGUAGE="JavaScript">
<!--

function refresh() {
	window.location='users.php?rid=<?=$rid?>&uid=<?=$uid?>&username=<?=$username?>';
}

function newImage(arg) {
	if (document.images) {
		rslt = new Image();
		rslt.src = arg;
		return rslt;
	}
}

function changeImages() {
	if (document.images && (preloadFlag == true)) {
		for (var i=0; i<changeImages.arguments.length; i+=2) {
			document[changeImages.arguments[i]].src = changeImages.arguments[i+1];
		}
	}
}

var preloadFlag = false;
function preloadImages() {
	if (document.images) {
        user1 = newImage("images/u1.gif");
        user2 = newImage("images/u2.gif");
		preloadFlag = true;
	}
}

function setFocus() {
  if (document.all) {
    top.wIn.document.all['form1'].txt.focus(); 
  } else {
    top.wIn.document.form1.txt.focus();
  }
}

function sendMessage(name) {
  if (document.all) {
    top.wIn.document.all['form1'].txt.value="/msg "+name+' '; 
  } else {
    top.wIn.document.form1.txt.value="/msg "+name+' ';
  }
  setFocus();
}

// -->
</SCRIPT>

</head>
<body bgcolor="#EEEEFF" marginwidth="0" marginheight="0" leftmargin="0" topmargin="0">
<font face="Verdana,sans-serif" size="-1" color="darkblue">
<a href="users.php?rid=<?=$rid?>&uid=<?=$uid?>&username=<?=$username?>">
<img src="images/users.gif" border="0"></a><br>
<small><nobr>

<?

$DbLink->query("select uid, name from ".$prefix."_chatuser where rid = ".$rid);
while(list($userid, $name) = $DbLink->next_record()) {   
  ?>
  <a href="javascript:sendMessage('<?=$name?>')" onMouseOver="document.images['im<?=$userid?>'].src='images/u2.gif'" onMouseOut ="document.images['im<?=$userid?>'].src='images/u1.gif'">
  <img src='images/u1.gif' alt='<?=$name?>' name='im<?=$userid?>' border='0'>
  <?
  if ( strlen($name) > 11 )
    $name = substr($name,0,10)."..";
  echo $name."</a><br>";
}
$DbLink->clean_results();
$DbLink->close();
?>
        
</nobr>
</small>
</font>
</body>
</html>
