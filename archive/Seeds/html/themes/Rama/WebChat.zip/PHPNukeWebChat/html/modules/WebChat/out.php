<?
/*****************************************************************************************
 *  WebChat - multiple private/open room chat system for PostNuke                        *
 *****************************************************************************************
 *   David "Cyklone" Thompson   david@thompsonville.net                                  *
 *   portions credited to Daniel Toma [dt@dnt.ro] [http://www.webdev.ro]                 *
 *****************************************************************************************
 *  Read CHANGELOG for updates and bug fixes                                             *
 *****************************************************************************************
 * POST-NUKE Content Management System                                                   *
 * Copyright (C) 2001 by the Post-Nuke Development Team.                                 *
 * http://www.postnuke.com/                                                              *
 * --------------------------------------------------------------------------------------*
 * Based on:                                                                             *
 * PHP-NUKE Web Portal System - http://phpnuke.org/                                      *
 * Thatware - http://thatware.org/                                                       *
 *****************************************************************************************/
?>
<html>
<head>
<link rel="stylesheet" href="main.css" type="text/css">
<style>
<!--
BODY {
  font-family: Verdana, sans-serif;
  color: #000055;
  font-size: 12px;
  font-weight: normal;
}
-->
</style>
<SCRIPT LANGUAGE="JavaScript">
<!--
scrolling=true;
function moves(){
    if(scrolling != false) { 
      window.scroll(1,5000000); 
    }
    window.setTimeout("moves()",100);
}
moves();

function newImage(arg) {
	if (document.images) {
		rslt = new Image();
		rslt.src = arg;
		return rslt;
	}
}

function changeImages() {
	if (document.images && (preloadFlag == true)) {
		for (var i=0; i<changeImages.arguments.length; i+=2) {
			document[changeImages.arguments[i]].src = changeImages.arguments[i+1];
		}
	}
}

var preloadFlag = false;
function preloadImages() {
	if (document.images) {
    useron      = newImage("images/u3.gif");
    useroff     = newImage("images/u4.gif");
    sound       = newImage("images/beep.gif");
<?
  require("./inc/config.php");
  require("./inc/mysql.lib.php");
  
  $DbSmiles = new DB($dbhost, $dbname, $dbuname, $dbpass);
  $DbSmiles->query("SELECT code, file, emotion FROM ".$prefix."_chatsmile");
  if($DbSmiles->num_rows() > 0) {
    while(list($code, $filename, $emotion, $length) = $DbSmiles->next_record()) {
      $emotion = strtr($emotion, " ", "_");
      echo "    ".$emotion." = newImage(\"".$smilesdir."/".$filename."\");\n";
    }
  }
  $DbSmiles->clean_results();
  $DbSmiles->close();
?>
		preloadFlag = true;
	}
}
// -->
</script>
</head>
<body bgcolor="#FFFFFF" onLoad="preloadImages()" onMouseOver="scrolling=false" onMouseOut="scrolling=true" marginwidth="0" marginheight="0" leftmargin="3" rightmargin="10" topmargin="3">
